#!/bin/bash

node=getaverse
pid=$(ps aux|grep ${node}|grep -v grep|awk '{print $2}')
if [ -z ${pid} ];then
    echo " ${node} isn't running."
    exit 0
fi
[ -n "${pid}" ] && kill ${pid} > /dev/null
